0x06. C Pointers, Arrays and Strings
